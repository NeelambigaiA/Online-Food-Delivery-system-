package com.example.demo.Controller;

import java.util.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import com.example.demo.DTO.OrderDetailsDTO;
import com.example.demo.DTO.OrderDetailsSaveDTO;
import com.example.demo.Service.OrderDetailsService;


	@CrossOrigin(origins="*")
	@RestController
	@RequestMapping("api/v1/orderdetails")
	public class OrderDetailsController{
		
		@Autowired
		private OrderDetailsService orderService ;
		
		@PostMapping(path="/save")
		public String saveOrder(@RequestBody OrderDetailsSaveDTO orderdetailssaveDTO )
		{
			String id=orderService.addOrderDetails(orderdetailssaveDTO);
			return id;
		}
		
		@GetMapping(path="/getAll")
		public List<OrderDetailsDTO>getAllorder()
		{
			List<OrderDetailsDTO>allOrder=orderService.getAllOrder();
			return allOrder;
		}
		

		
		@DeleteMapping(path="/deleteOrder/{id}")
		public String deleteOrder(@PathVariable(value="id")int id)
		{
			boolean deleteFood=orderService.deleteOrder(id);
			return "Order deleted";
		}


}