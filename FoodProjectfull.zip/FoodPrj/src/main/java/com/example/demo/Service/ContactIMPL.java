package com.example.demo.Service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.DTO.ContactDTO;
import com.example.demo.DTO.ContactSaveDTO;
import com.example.demo.DTO.OrderDetailsDTO;
import com.example.demo.Model.Contact;
import com.example.demo.Model.OrderDetails;
import com.example.demo.Repository.ContactRepo;


@Service
public class ContactIMPL implements ContactService{ 
	@Autowired
	private ContactRepo contactrepo;

	@Override
	public String addContact(ContactSaveDTO contactsaveDTO) {
		Contact contact = new Contact(0,contactsaveDTO.getName(),contactsaveDTO.getEmail(),
				contactsaveDTO.getPhoneno(),contactsaveDTO.getMessage());
		contactrepo.save(contact);
		return "Saved";
	}

	@Override
	public List<ContactDTO> getAllContact() {
		List<Contact> getContact = contactrepo.findAll();
		List<ContactDTO> ContactDTOList = new ArrayList<>();
		for (Contact a : getContact) {
			ContactDTO contactDTO = new ContactDTO(a.getId(),a.getName(),a.getEmail(),a.getPhoneno(),a.getMessage());
			ContactDTOList.add(contactDTO);
		}
		return ContactDTOList;
	}

	@Override
	public boolean deleteContact(int id) {
		if (contactrepo.existsById(id)) {
			contactrepo.deleteById(id);
		} else {
			System.out.println("Contact is Not found..");
		}
		return true;
	}

	
}
