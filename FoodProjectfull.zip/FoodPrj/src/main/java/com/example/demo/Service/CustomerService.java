package com.example.demo.Service;

import com.example.demo.DTO.CustomerDTO;

import com.example.demo.DTO.CustomerSaveDTO;

import com.example.demo.Model.CustomerRegister;


import java.util.*;
public interface CustomerService {
	String addCustomer(CustomerSaveDTO customerSaveDTO );
	List<CustomerDTO>getAllCustomers();
	CustomerRegister updateCustomer(CustomerRegister Customer, int id);
	boolean deleteCustomer(int id);
	List<CustomerRegister>getAllCustomersByUsername(String username);
}
