package com.example.demo.Service;

import java.util.List;


import com.example.demo.DTO.CustomerDTO;
import com.example.demo.DTO.CustomerSaveDTO;
import com.example.demo.DTO.OrderDetailsDTO;
import com.example.demo.DTO.OrderDetailsSaveDTO;
import com.example.demo.Model.CustomerRegister;

public interface OrderDetailsService {
	String addOrderDetails(OrderDetailsSaveDTO orderdetailssaveDTO );
	List<OrderDetailsDTO>getAllOrder();
	boolean deleteOrder(int id);


}

