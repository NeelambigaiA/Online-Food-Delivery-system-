package com.example.demo.DTO;


public class OrderDetailsDTO {
	private int orderId;
	private String FoodName;
	private int foodprice;
	private String foodimage;
	private int foodQuantity;
	private int totalPrice;

	public OrderDetailsDTO() {
		super();

	}

	public int getOrderId() {
		return orderId;
	}

	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}

	public String getFoodName() {
		return FoodName;
	}

	public void setFoodName(String foodName) {
		FoodName = foodName;
	}

	public int getFoodprice() {
		return foodprice;
	}

	public void setFoodprice(int foodprice) {
		this.foodprice = foodprice;
	}

	public String getFoodimage() {
		return foodimage;
	}

	public void setFoodimage(String foodimage) {
		this.foodimage = foodimage;
	}

	public int getFoodQuantity() {
		return foodQuantity;
	}

	public void setFoodQuantity(int foodQuantity) {
		this.foodQuantity = foodQuantity;
	}

	public int getTotalPrice() {
		return totalPrice;
	}

	public void setTotalPrice(int totalPrice) {
		this.totalPrice = totalPrice;
	}


	public OrderDetailsDTO(int orderId, String foodName, int foodprice, String foodimage, int foodQuantity,
			int totalPrice) {
		super();
		this.orderId = orderId;
		FoodName = foodName;
		this.foodprice = foodprice;
		this.foodimage = foodimage;
		this.foodQuantity = foodQuantity;
		this.totalPrice = totalPrice;
	}

	@Override
	public String toString() {
		return "OrderDetailsDTO [orderId=" + orderId + ", FoodName=" + FoodName + ", foodprice=" + foodprice
				+ ", foodimage=" + foodimage + ", foodQuantity=" + foodQuantity + ", totalPrice=" + totalPrice + "]";
	}

	


}
